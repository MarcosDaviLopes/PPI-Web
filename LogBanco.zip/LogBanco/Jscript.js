setTimeout(function(){
    window.location.href = 'index.php';
}, 5000);